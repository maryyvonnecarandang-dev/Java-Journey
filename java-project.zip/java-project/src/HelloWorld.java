public class HelloWorld{
    public static void main(String args[]){
        System.out.println("Hello, I'm Yvonne!");

        int x = 5;
        if (x <= 10){
            System.out.println("Number is less than 10.");
        }
        else{
            System.out.println("Nember is greater than 10");
        }
            
        
    }
}
